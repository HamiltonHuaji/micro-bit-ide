# Thonny插件thonny-microbit 改造版
增加对扩展套件的支持

## 使用方式：
整个文件夹放置于thonny/plugins